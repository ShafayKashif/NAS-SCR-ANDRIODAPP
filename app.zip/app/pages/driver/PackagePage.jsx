import React, {useState} from 'react'
import {View, Text} from 'react-native'

const PackagePage=()=>{
    return (
        <View>
            <Text>
                Package
            </Text>
        </View>
    );

}

export default PackagePage;